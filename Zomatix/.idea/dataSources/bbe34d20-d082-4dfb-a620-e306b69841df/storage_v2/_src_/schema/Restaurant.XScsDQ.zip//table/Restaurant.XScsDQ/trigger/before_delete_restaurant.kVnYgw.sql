create trigger before_delete_restaurant
  before DELETE
  on Restaurant
  for each row
BEGIN
    delete from Menu where restaurantid = OLD.restaurantid;
  END;

