create trigger before_delete_menu
  before DELETE
  on Menu
  for each row
BEGIN
    delete from Item where menuid = OLD.menuid;
  END;

