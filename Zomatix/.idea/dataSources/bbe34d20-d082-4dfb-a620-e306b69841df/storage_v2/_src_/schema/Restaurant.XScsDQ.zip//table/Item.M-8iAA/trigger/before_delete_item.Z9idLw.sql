create trigger before_delete_item
  before DELETE
  on Item
  for each row
BEGIN
    delete from Item_ingredients where itemid = OLD.itemid;
  END;

