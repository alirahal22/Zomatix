create trigger before_rating_insert
  before INSERT
  on Rating
  for each row
BEGIN
    update restaurant set number_of_ratings = (number_of_ratings + 1), total_ratings = (total_ratings + NEW.rating) where restaurantid = NEW.restaurantid;
    update restaurant set rating = total_ratings / number_of_ratings where restaurantid = NEW.restaurantid;
END;

